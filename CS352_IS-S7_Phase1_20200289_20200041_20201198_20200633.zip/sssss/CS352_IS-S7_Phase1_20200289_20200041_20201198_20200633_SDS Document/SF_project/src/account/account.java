package account;

public abstract class account {
	public String name;
	public String email;
	public int pass;
}
