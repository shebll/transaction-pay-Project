package services;

public class Donations extends Services {

}
