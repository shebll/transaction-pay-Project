package services;

public class Internet extends Services  {

}
