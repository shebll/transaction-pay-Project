package services;

public class Landline extends Services  {

}
