package observer;

public interface Observer {
	void update(String massage) ;
}
