package com.swe.Services.bsl;
import java.util.*;

import com.swe.Services.controllers.AdminController;
import com.swe.Services.models.Payment;
import com.swe.Services.models.User;
import com.swe.Services.models.Admin;
import lombok.val;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
@Service
public class PaymentDigitalWalletBsl {
    Payment payment;
    public PaymentDigitalWalletBsl() {
    }


    public String pay(User user,String serviceName ,String provider ,double amount ){

        payment =new Payment(user) ;

        if(amount>user.welletBalance){
            return "error amount is bigger than your balance!";
        }else {
            user.welletBalance -= amount;
            payment.wallet_balance-=amount ;
            String ss = payment.wallet_balance+"";
            String x= user.welletBalance +"";
            String s = serviceName + "/Provider:" + provider;
            payment.userObj.listOfPayment_name.add(s);
            payment.userObj.listOfPayment_amount.add(amount);

            return "Transfer successfully.";
        }


    }

    public void  getBalance(){
        System.out.println("\n"+payment.userObj.name+"'s balance: "+payment.wallet_balance+"\n");
    }
    public void setBalance(double _b){
        payment.wallet_balance+=_b;
    }


}
